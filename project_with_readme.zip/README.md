
# GR14 Dynamic Medical Network Defense Framework

This repository provides the core reproducible implementation associated with the GR14 revised manuscript.  
The code demonstrates a reinforcement-learning driven dynamic defense architecture designed for medical IoMT networks.

The framework integrates four major components described in the manuscript:

1. Threat Scoring Module
2. RL-based Dynamic Defense Strategy
3. Resource Scheduling Module
4. Blockchain-based Strategy Verification (Improved PBFT)

The implementation is designed for transparency and reproducibility and can be used for simulation experiments or methodological verification.

---

# Repository Structure

threat_scoring.py
Implements the threat assessment model using three weighted indicators:
- vulnerability severity
- traffic anomaly score
- historical attack frequency

The module calculates the real-time threat score and determines the corresponding defense level.

rl_defense.py
Implements the reinforcement learning defense agent using a DQN-style architecture.
Key features include:
- six-dimensional system state representation
- six defense actions
- epsilon-greedy exploration
- replay buffer training
- PyTorch implementation

resource_scheduler.py
Implements the dynamic resource scheduling mechanism for the medical system.
The scheduler allocates computing and storage resources under constraints such as:
- latency SLA
- CPU usage
- memory limits
- edge device power budget

pbft_and_training.py
Implements the blockchain-based defense verification and the end-to-end training pipeline.
The module simulates an improved PBFT consensus mechanism to validate defense strategies across distributed nodes.

---

# State Representation

The reinforcement learning agent uses the following six state variables:

1. vulnerability severity score
2. traffic anomaly score
3. network load
4. device criticality
5. clinical priority
6. attack type identifier

These variables correspond to the security context of medical IoMT devices.

---

# Defense Action Space

The system defines six defense strategies:

1. encrypted tunnel switch
2. protocol hopping
3. traffic cleaning
4. edge resource scheduling
5. full isolation
6. patch distribution

Each action affects both security effectiveness and service performance.

---

# Reward Function

The reward function balances security protection, operational efficiency, and system cost:

Reward = 0.5 * SecurityReward + 0.3 * EfficiencyReward − 0.2 * CostPenalty

This design encourages the agent to maximize protection while maintaining service continuity.

---

# Dependencies

Python 3.9+

Required libraries:

numpy  
pandas  
torch  

Install using:

pip install numpy pandas torch

---

# Example Usage

Train the dynamic defense agent:

python pbft_and_training.py

The training script loads the dataset, initializes the environment, and trains the RL defense model.

---

# Data Availability

Synthetic datasets used for demonstration and reproducibility can be generated using the accompanying scripts.

Sensitive clinical datasets referenced in the manuscript are not publicly released due to privacy and ethical constraints but are available from the authors upon reasonable request and subject to institutional approval.

---

# Reproducibility Statement

This repository provides a simplified but faithful implementation of the core algorithmic pipeline described in the manuscript. The code is intended to facilitate reproducibility of the experimental methodology and enable independent verification of the proposed defense framework.

